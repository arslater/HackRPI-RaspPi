#!/usr/bin/env bash
# Remove Node.js from your Raspbian.

rm /usr/local/bin/node
rm /usr/local/bin/npm
rm -rf /usr/local/include/node
rm -rf /usr/local/lib/node_modules
rm -rf /usr/local/share/doc/node
rm /usr/local/share/man/man1/node.1
rm /usr/local/share/systemtap/tapset/node.stp
